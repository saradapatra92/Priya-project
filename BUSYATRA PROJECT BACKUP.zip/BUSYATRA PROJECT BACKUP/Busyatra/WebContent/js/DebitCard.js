/**
 * 
 */
function doValidate() {

	var error="";
	
	var name=frmRegister.cardname.value;
	var patt3 =/^[A-Z a-z]+$/;
	if(!name.match(patt3))
	{
		error+="Enter a valid Name\n";
		document.getElementById("errName").innerHTML="Enter a valid Name";	
		return false;
	}
	else {
		document.getElementById("errName").innerHTML = "";
		
	}
	
	var debitNo=frmRegister.cardnumber.value;
	var patt1 =/^\d{16}$/;
	if(!debitNo.match(patt1))
	{
		error+="Enter 16 digits Credit card Number\n";
		document.getElementById("errDebitNo").innerHTML="Enter 16 digits Credit card Number";	
		return false;
	}
	else {
		document.getElementById("errDebitNo").innerHTML = "";
		
	}
	
	
	var cvv=frmRegister.cvv.value;
	var patt2 =/^[0-9]{3}$/;
	if(!cvv.match(patt2))
	{
		error+="Enter a valid CVV\n";
		document.getElementById("errCVV").innerHTML="Enter a valid CVV";	
		return false;
	}
	else {
		document.getElementById("errCVV").innerHTML = "";
		
	}
	
	
}
	
	
	