/**
 * 
 */


function doValidate() {

	var error="";
	var accNo=frmRegister.Acountnumber.value;
	var reAccNo=frmRegister.RepeatAcountnumber.value;
	var patt1 =/^\d{16}$/;
	if(!accNo.match(patt1))
	{
		error+="Enter 16 digits Account Number\n";
		document.getElementById("errAccNo").innerHTML="Enter 16 digits Account Number";	
		return false;
	}
	else {
		document.getElementById("errAccNo").innerHTML = "";
		
	}
	
	var p1=frmRegister.Acountnumber.value;
	var p2=frmRegister.RepeatAcountnumber.value;
	
	if(p1!= p2){
	
		error+="Account Number Mismatch";
		document.getElementById("errReAccNo").innerHTML="Account Number Mismatch";
		return false;
	}
	else {
		document.getElementById("errReAccNo").innerHTML = "";
		
	}
	
	var ifsc=frmRegister.IFSCcode.value;
	var patt2 =/^[A-Za-z]{4}\d{7}$/;
	if(!ifsc.match(patt2))
	{
		error+="Enter a valid IFSC code\n";
		document.getElementById("errifsc").innerHTML="Enter a valid IFSC code";	
		return false;
	}
	else {
		document.getElementById("errifsc").innerHTML = "";
		
	}
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
