/**
 * 
 */
function doValidate()
{
	var error="";
	
	var source=frmSearch.source.value;
	var destination = frmSearch.destination.value;
	
	if((source==destination))
		{
		
		error+="Souce and Destination cannot be same";
		document.getElementById("errSrc").innerHTML="Souce and Destination cannot be same";
		return false;
	}
	else {
		document.getElementById("errSrc").innerHTML = "";
		
	}
	

}