/**
 * 
 */
function doValidate() {




	var regNo=frmRegister.busregNo.value;
	if(!regNo.match(/^[A-Z]{2}[-][0-9]{2}[-][A-Z]{2}[-][0-9]{4}/))
	{
		error+="Please enter a valid format e.g 'OD-01-GH-2345'\n";
		document.getElementById("errRegistrationNo").innerHTML="Enter valid Registration Number";
		return false;
	}
	else {
		document.getElementById("errRegistrationNo").innerHTML = "";
		
	}
}
