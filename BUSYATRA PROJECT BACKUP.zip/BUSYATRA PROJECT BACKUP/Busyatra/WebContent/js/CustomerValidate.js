/**
 * 
 */


function doValidate() {
	
	var error="";
	

	var name=frmRegister.name.value;
	
	if(!name.match(/^[A-Za-z ]+$/)){
		error+="Enter Valid Name\n";
		document.getElementById("errName").innerHTML="Enter Valid Name";
		
		return false;
	}
	else {
		document.getElementById("errName").innerHTML = "";
		
	}

	var email=frmRegister.email.value;
	 if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)))
	 {
		 error+="You have entered an invalid email address!\n";
		 document.getElementById("errEmail").innerHTML="Enter Valid Email";
		 
	    return false;
	}
	 else {
			document.getElementById("errEmail").innerHTML = "";
			
		}

	 var mob=frmRegister.mobile.value;
		var patt1 =/^\d{10}$/;
		if(!mob.match(patt1)){
			error+="Enter Valid Mobile Number\n";
			document.getElementById("errMobileNumber").innerHTML="Enter 10 digit Mobile Number";
			// alert("Enter Valid Mobile Number");
			return false;
		}
		else {
			document.getElementById("errMobileNumber").innerHTML = "";
			
		}

	
	var p1=frmRegister.password.value;
	var p2=frmRegister.retypePassword.value;
	
	
	
	var letters = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/; 
	if(!(p1.match(letters)))
	{
		
		error+="Password too short\n";
		document.getElementById("errPassword").innerHTML="Please input alphanumeric characters only";
		//alert('Please input alphanumeric characters only');
		return false;
	}
	else {
		document.getElementById("errPassword").innerHTML = "";
		
	}

	
	if(p1!=p2)
	{
		
		error+="Password Mismatch";
		document.getElementById("errRePassword").innerHTML="Password Mismatch";
		return false;
		
	}
	else {
		document.getElementById("errRePassword").innerHTML = "";
		
	}

	
	
	
	
	
	
	 
	 
	
	 
}