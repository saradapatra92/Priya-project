/**
 * 
 */
function doValidate(){
var error="";
	

	

	var email=frmData.passengerEmail.value;
	 if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)))
	 {
		 error+="You have entered an invalid email address!\n";
		 document.getElementById("errEmail").innerHTML="Enter Valid Email";
		 
	    return false;
	}
	 else {
			document.getElementById("errEmail").innerHTML = "";
			
		}

	 var mob=frmData.passengerMobile.value;
		var patt1 =/^\d{10}$/;
		if(!mob.match(patt1)){
			error+="Enter Valid Mobile Number\n";
			document.getElementById("errMobileNumber").innerHTML="Enter 10 digit Mobile Number";
			// alert("Enter Valid Mobile Number");
			return false;
		}
		else {
			document.getElementById("errMobileNumber").innerHTML = "";
			
		}
}