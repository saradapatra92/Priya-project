/**
 * 
 */

function doValidate() {




	var regNo=frmRegister.busregNo.value;
	if(!regNo.match(/^[A-Z]{2}[-][0-9]{2}[-][A-Z]{2}[-][0-9]{4}/))
	{
		error+="Please enter a valid format e.g 'OD-01-GH-2345'\n";
		document.getElementById("errRegistrationNo").innerHTML="Enter valid Registration Number";
		return false;
	}
	else {
		document.getElementById("errRegistrationNo").innerHTML = "";
		
	}
	


	var name=frmRegister.busname.value;
	if(!name.match(/^[A-Za-z ]+$/)){
		error+="Enter Valid Name\n";
		document.getElementById("errBusName").innerHTML="Enter Valid Name";
		return false;
	}
	else {
		document.getElementById("errBusName").innerHTML = "";
		
	}
	


	var source=frmRegister.source.value;
	if(!source.match(/^[A-Za-z ]+$/)){
		error+="Enter Valid Source Name\n";
		document.getElementById("errSource").innerHTML="Enter Valid Source Name";
		return false;
	}
	else {
		document.getElementById("errSource").innerHTML = "";
		
	}
	


	var destination=frmRegister.destination.value;
	if(!destination.match(/^[A-Za-z ]+$/)){
		error+="Enter Valid Destination Name\n";
		document.getElementById("errDestination").innerHTML="Enter Valid Destination Name";
		return false;
	}
	else {
		document.getElementById("errDestination").innerHTML = "";
		
	}
	

	var mob=frmRegister.driverNumber.value;
	var patt1 =/^\d{10}$/;
	if(!mob.match(patt1)){
		error+="Enter Valid Mobile Number\n";
		document.getElementById("errPhoneNo").innerHTML="Enter 10 digit Mobile Number";
		return false;
	}
	else {
		document.getElementById("errPhoneNo").innerHTML = "";
		
	}
	
	
	var totalSeats=frmRegister.totalSeats.value;
	var patt1 =/^\d{2}$/;
	if(!totalSeats.match(patt1)){
		error+="Enter Numeric\n";
		document.getElementById("errTotalSeats").innerHTML="Enter Numeric";
		return false;
	}
	else {
		document.getElementById("errTotalSeats").innerHTML = "";
		
	}

	



}