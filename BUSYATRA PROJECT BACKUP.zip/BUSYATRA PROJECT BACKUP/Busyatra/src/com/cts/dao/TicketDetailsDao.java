package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
/*
import com.cts.Helper.DBUtility;*/
import com.cts.TO.TicketCancelTO;
import com.cts.datasource.SingleTonConnection;
import com.cts.utilities.PropertyUtil;

public class TicketDetailsDao {
	
	private  static Logger logger = Logger.getLogger(TicketDetailsDao.class);
	 
	public List<TicketCancelTO> showTickets(String custid) throws SQLException {
			Connection con=SingleTonConnection.getInstance().getConnection();
			String cmdcount="select count(*) cnt from ticketdetails where Custid=? ";
			String sqlCmd = "select * from ticketdetails where Custid=? ";
			List<TicketCancelTO> ticket=new ArrayList<TicketCancelTO>();
			try {
				PreparedStatement pst = con.prepareStatement(cmdcount);

				pst.setString(1, custid);
				ResultSet rs = pst.executeQuery();
				rs.next();
				int count = rs.getInt("cnt");
				if (count == 0) {
					ticket = null;
				}
				else {
					pst = con.prepareStatement(sqlCmd);
					pst.setString(1, custid);
					
					rs = pst.executeQuery();
					TicketCancelTO t = null;
					int i = 0;
					int s=0;
					while (rs.next()) {
					
					
						t = new TicketCancelTO();
						t.setBusRegNum(rs.getString("busRegNum"));
						t.setStatus(rs.getString("status"));
						t.setCustid(rs.getString("custid"));
						t.setTicketid(rs.getString("ticketid"));
						t.setBusname(rs.getString("busname"));
						t.setSource(rs.getString("Source"));
						t.setDestination(rs.getString("Destination"));
						t.setBookingdate(rs.getDate("bookingdate"));
						t.setJourneydate(rs.getDate("journeydate"));
						t.setArrivaltime(rs.getString("arrivaltime"));
						t.setDeparttime(rs.getString("departtime"));

						ticket.add(t);
						i++;
					
					}
				
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));
			}
			finally{
				con.close();
			}
			return ticket;	
				
			
		}

}
