package com.cts.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;



//import com.cts.beans.Customer;
import com.cts.TO.*;
/*import com.cts.Helper.DBUtility;
*/
import com.cts.controller.*;
import com.cts.datasource.SingleTonConnection;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;
import com.cts.utilities.PropertyUtil;
public class AddBusDAO {
	private  static Logger logger = Logger.getLogger(AddBusDAO.class);
	
	public String addPassengerDetails(Passenger p) throws ValidationException,DatabaseException, SQLException{
		
		
		Connection con=SingleTonConnection.getInstance().getConnection();
		String cmdp="Insert into Passenger(CustomerName,BusregNum,age,gender,dateofjourney,TicketStatus) values(?,?,?,?,?,?)";
		String res="";
		PreparedStatement pst;
		try {
			pst = con.prepareStatement(cmdp);
			pst.setString(1,p.getCustomerName());
			pst.setString(2,p.getBusRegNum());
			pst.setString(3,p.getAge());
			pst.setString(4,p.getGender());
			pst.setDate(5,p.getDateofjourney());
			pst.setString(6,p.getTicketStatus());
			pst.executeUpdate();
			res="Passenger Details Stored Successfully...";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			res=e.getMessage();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		finally{
			con.close();
		}
		return res;
	
	}
	
	public boolean isBusExists(String busRegNum, Date date) throws ValidationException,DatabaseException, SQLException 
	{
		
		AddBusTO admin= new AddBusTO();
		boolean flag = false;
		String userCmd = "select * from busdetails where busRegNum = ? and dateofjourney=?";
		Connection con=SingleTonConnection.getInstance().getConnection();
		try {
			PreparedStatement pst = con.prepareStatement(userCmd);
			pst.setString(1, busRegNum);
			pst.setDate(2, date);

			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				flag = true;
			}
		} catch (SQLException e)
		{
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		finally{
			con.close();
		}
		return flag;
	}
	
	
	
	public boolean addBusDetails(AddBusTO admin) throws ValidationException,DatabaseException, SQLException{
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		AddBusDAO addBusDetails= new AddBusDAO();
		
		boolean flag = addBusDetails.isBusExists(admin.getBusRegNum(),admin.getDate());
		boolean msg = false;
		if (flag == false) {
			Connection con=SingleTonConnection.getInstance().getConnection();
			String busIns = "Insert into Busdetails(busRegNum ,busname,source,destination,busType,startTime,endTime,fare,driverName,driverNumber,TotalSeats,availableseats,dateofjourney) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
			try {
				PreparedStatement pst = con.prepareStatement(busIns);
				pst.setString(1,admin.getBusRegNum());
				pst.setString(2,admin.getBusname());
				pst.setString(3,admin.getSource());
				pst.setString(4,admin.getDestination());
				pst.setString(5,admin.getBusType());
				pst.setString(6,admin.getStartTime());
				pst.setString(7,admin.getEndTime());
				pst.setDouble(8,admin.getFare());
				pst.setString(9,admin.getDriverName());
				pst.setString(10,admin.getDriverNumber());
				pst.setInt(11,admin.getTotalSeats());
				pst.setInt(12,admin.getTotalSeats());
				pst.setDate(13,admin.getDate());
				int n=pst.executeUpdate();
				if(n>0)
				{
					msg=true;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));
			}
			finally{
				con.close();
			}
		}
		return msg;
	}
	
	
	
}
