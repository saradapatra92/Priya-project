package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

/*import com.cts.Helper.DBUtility;*/
import com.cts.TO.DeleteBusTO;
import com.cts.datasource.SingleTonConnection;
import com.cts.utilities.PropertyUtil;

public class DeleteBusDAO {

	private  static Logger logger = Logger.getLogger(DeleteBusDAO.class);
	
	public boolean isBusExists(String busRegNum) throws SQLException {
		boolean flag = false;
		String userCmd = "select busRegNum from busdetails where busRegNum=?";
		Connection con=SingleTonConnection.getInstance().getConnection();
		try {
			PreparedStatement pst = con.prepareStatement(userCmd);
			pst.setString(1, busRegNum);
			ResultSet rs = pst.executeQuery();

			if (rs.next()) 
			{
				flag = true;
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		finally{
			con.close();
		}
		return flag;
	}

	public boolean getBusDetails(DeleteBusTO objDelete) throws SQLException
	{
		DeleteBusDAO deldao=new DeleteBusDAO();
		String busRegNum= objDelete.getBusRegNum();
		boolean flag = deldao.isBusExists(busRegNum);
		boolean msg = false;
		if(flag==true)
		{
			String query="delete from busdetails where busRegNum =?";
			Connection con=SingleTonConnection.getInstance().getConnection();
			PreparedStatement pst;
			try {
				pst= con.prepareStatement(query);
				pst.setString(1, busRegNum);
				int n=pst.executeUpdate();
				if(n>0)
				{
					msg= true;
				}
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));

			}
			finally{
				con.close();
			}
		}
		return msg;
	}
}
