package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import com.cts.TO.UserDetails;
import com.cts.TO.UserLogin;
import com.cts.datasource.SingleTonConnection;
import com.cts.utilities.PropertyUtil;

public class LoginDetailsDao {

	private  static Logger logger = Logger.getLogger(LoginDetailsDao.class);
	
	public String validateLoginDetails(String email,String pwd) throws SQLException{
		String query="select name from customerdetails where email=? AND password=?";
		String name="";
		Connection con=SingleTonConnection.getInstance().getConnection();
		PreparedStatement pst;
		try {
			
			pst = con.prepareStatement(query);
			pst.setString(1, email);
			pst.setString(2,pwd);
			ResultSet rs= pst.executeQuery();
			if (rs.next()) {
				name=rs.getString(1);
			}
			else {
				name=null;
			}
	}catch (SQLException e) {
	e.printStackTrace();
		logger.error(PropertyUtil.getMessage(e.getMessage()));
		
	}
		finally{
			con.close();
		}
		return name;
	}
	
	public boolean isUserExists(String email) throws SQLException{
		boolean flag=false;
		Connection con=SingleTonConnection.getInstance().getConnection();
		String cmd="select email from customerdetails where email=?";
		try {
			PreparedStatement pst=con.prepareStatement(cmd);
			pst.setString(1,email);
			ResultSet rs=pst.executeQuery();
			if(rs.next()){
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		finally{
			con.close();
		}
		return flag;
	}
	
	public boolean addUserDetails(UserDetails objUser) throws SQLException
	{
		
		String name=objUser.getName();
		String email=objUser.getEmail();
		String mobileNo=objUser.getMobileNo();
		String password=objUser.getPassword();
		String gender=objUser.getGender();
		String address=objUser.getAddress();
		String city=objUser.getCity();
		String state=objUser.getState();
		String country=objUser.getCountry();
		Connection con=SingleTonConnection.getInstance().getConnection();
		boolean res=isUserExists(email);
		boolean result=true;
		if(res==false){
			String inUser="Insert into CustomerDetails(name,email,MobileNumber,Password,gender,address,city,state,country) "
					+ " values(?,?,?,?,?,?,?,?,?)";
			PreparedStatement pst;
			try {
				pst = con.prepareStatement (inUser);
				
				pst.setString(1, name);
				pst.setString(2, email);
				pst.setString(3, mobileNo);
				pst.setString(4, password);
				pst.setString(5, gender);
				pst.setString(6, address);
				pst.setString(7, city);
				pst.setString(8, state);
				pst.setString(9, country);
				int n=pst.executeUpdate();
				if(n>0)
				{
					result=true;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));
			}
			finally{
				con.close();
			}
		}
			
		if(res==true){
			result=false;
		}
		
		return result;
	}
	
	
}
