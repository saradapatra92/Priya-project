package com.cts.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

/*import com.cts.Helper.DBUtility;*/
import com.cts.TO.AddBusTO;
import com.cts.TO.BookingTO;
import com.cts.TO.BusTO;
import com.cts.TO.CancelTO;
import com.cts.TO.DeleteBusTO;
import com.cts.TO.Passenger;
import com.cts.TO.PassengerTO;
import com.cts.TO.TicketTO;
import com.cts.TO.UpdateBusTO;
import com.cts.datasource.SingleTonConnection;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;
import com.cts.utilities.PropertyUtil;

public class BusDetailsDao {

	private static Logger logger = Logger.getLogger(BusDetailsDao.class);
	
	public TicketTO bookTicket(PassengerTO objPassenger) throws ParseException,
			SQLException {

		String customerId = objPassenger.getCustid();
		String name = objPassenger.getName();
		String age = objPassenger.getAge();
		String number = objPassenger.getNumber();
		String email = objPassenger.getEmail();
		String gender = objPassenger.getGender();
		String busid = objPassenger.getBusid();
		int seats = objPassenger.getSeats();
		Date journeyDate = (Date) objPassenger.getJourneyDate();

		String query = "select source,destination,startTime,endTime,fare,drivername,drivernumber,busname from busdetails where busregnum=? and dateofjourney=?";
		Connection con = SingleTonConnection.getInstance().getConnection();

		ResultSet rs = null;
		PreparedStatement pst;
		String busName = "";
		String source = "";
		String destination = "";
		String dtime = "";
		String atime = "";
		String dname = "";
		String dnumber = "";
	
		int fare = 0;

		try {

			pst = con.prepareStatement(query);
			pst.setString(1, busid);
			pst.setDate(2, journeyDate);

			rs = pst.executeQuery();
			rs.next();
			source = rs.getString(1);
			destination = rs.getString(2);
			dtime = rs.getString(3);
			atime = rs.getString(4);
			fare = rs.getInt(5) * seats;
			dname = rs.getString(6);
			dnumber = rs.getString(7);
			busName = rs.getString(8);

		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}

		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		java.util.Date date = new java.util.Date();
		String dt = dateFormat.format(date);
		java.util.Date d = dateFormat.parse(dt);
		java.sql.Date bookingDate = new java.sql.Date(d.getTime());


		Random rand = new Random();
		String ticketId = "";
		pst = con
				.prepareStatement("select ticketid from ticketdetails where ticketid=?");
		do {
			rs = null;
			
			ticketId = busid.substring(0, 2)
					+ number.substring(number.length() - 3)
					+ customerId.substring(0, 4)
					+ String.format("%04d", rand.nextInt(10000));

			pst.setString(1, ticketId);
			rs = pst.executeQuery();

			if (!(rs.next())) {
				break;
			}

		} while (true);
		TicketTO ticket = new TicketTO(customerId, ticketId, busName, source,
				destination, dtime, atime, journeyDate, bookingDate, name, age,
				number, email, gender, busid, seats, fare, dname, dnumber);
		String cmd = "insert into ticketdetails (custid, ticketid, customername, busname, source, destination, departtime, busregnum, age, gender, email, mobile, arrivaltime, journeydate, bookingdate, tickets,fare) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try {

			pst = con.prepareStatement(cmd);
			pst.setString(1, customerId);
			pst.setString(2, ticketId);
			pst.setString(3, name);
			pst.setString(4, busName);
			pst.setString(5, source);
			pst.setString(6, destination);
			pst.setString(7, dtime);
			pst.setString(8, busid);
			pst.setString(9, age);
			pst.setString(10, gender);
			pst.setString(11, email);
			pst.setString(12, number);
			pst.setString(13, atime);
			pst.setDate(14, journeyDate);
			pst.setDate(15, bookingDate);
			pst.setInt(16, seats);
			pst.setInt(17, fare);

			pst.executeUpdate();

			query = "update busdetails set availableseats=availableseats-?, amount=amount+? where busregnum=? and dateofjourney=?";
			pst = con.prepareStatement(query);
			pst.setInt(1, seats);
			pst.setInt(2, fare);
			pst.setString(3, busid);
			pst.setDate(4, journeyDate);
			pst.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		finally
		{
			con.close();
		}

		return ticket;

	}

	public boolean isBusExists(String busRegNum) throws ValidationException,
			DatabaseException, SQLException {
		boolean flag = false;
		String userCmd = "select busRegNum from busdetails where busRegNum=?";
		Connection con = SingleTonConnection.getInstance().getConnection();
		try {
			PreparedStatement pst = con.prepareStatement(userCmd);
			pst.setString(1, busRegNum);
			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				flag = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		finally
		{
			con.close();
		}
		return flag;
	}

	public boolean deleteBusDetails(DeleteBusTO objDelete) throws ValidationException,
			DatabaseException, SQLException {
		DeleteBusDAO deldao = new DeleteBusDAO();
		String busRegNum = objDelete.getBusRegNum();
		boolean flag = deldao.isBusExists(busRegNum);
		boolean msg = false;
		if (flag == true) {
			String query = "delete from busdetails where busRegNum =?";
			Connection con = SingleTonConnection.getInstance().getConnection();
			PreparedStatement pst;
			try {
				pst = con.prepareStatement(query);
				pst.setString(1, busRegNum);
				int n = pst.executeUpdate();
				if (n > 0) {
					msg = true;
				}
			} catch (SQLException e) {
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));

			}
			finally
			{
				con.close();
			}
		}
		return msg;
	}

	
	public List<BusTO> getBusDetails(BookingTO objBooking) throws ValidationException,DatabaseException, SQLException {
		
		 String source=objBooking.getSource();
		 String destination= objBooking.getDestination();
		 java.sql.Date startDate=objBooking.getStartDate();
		 int seats=objBooking.getSeats();
		 
		 List<BusTO> arrayBus= new ArrayList<BusTO>();
		 
		 String query="select * from busdetails where source=? and destination=? and dateofjourney=? and availableSeats>0 and availableSeats>=?";
		
		 Connection con=SingleTonConnection.getInstance().getConnection();
		 
		 ResultSet rs= null;
		 PreparedStatement pst;
			try {
				
				pst = con.prepareStatement (query);
				
				pst.setString(1, source);
				pst.setString(2, destination);
				pst.setDate(3, startDate);
				pst.setInt(4, seats);				
				rs=pst.executeQuery();
				
				int count=0;
				
				if(rs!=null){
					while(rs.next()){
						count++;
					}
				}
				
				if(count==0){
					arrayBus=null;
				}
				else{
					pst = con.prepareStatement (query);
					
					pst.setString(1, source);
					pst.setString(2, destination);
					pst.setDate(3, startDate);
					pst.setInt(4, seats);					
					rs=pst.executeQuery();
					
					BusTO objBus= null;
					
					
					
					int i=0;
					while(rs.next()){
						
						objBus=new BusTO();
						objBus.setBusReg(rs.getString(1));
						
						objBus.setType(rs.getString(5));
						
						objBus.setStime(rs.getString(6));
						
						objBus.setEtime(rs.getString(7));
						
						objBus.setSeats(rs.getInt(12));
						
						objBus.setFare(rs.getInt(8));
						
						objBus.setJourneyDate(startDate);
						
						arrayBus.add(objBus);
						i++;
					}
					
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));
			}
			finally{
				con.close();
			}
			
			return arrayBus;
		
	}

	public boolean isBusExists(String busRegNum, Date date)
			throws ValidationException, DatabaseException, SQLException {

		AddBusTO admin = new AddBusTO();
		boolean flag = false;
		String userCmd = "select busRegNum,date from busdetails where busRegNum = ? and dateofjourney=?";
		Connection con = SingleTonConnection.getInstance().getConnection();
		try {
			PreparedStatement pst = con.prepareStatement(userCmd);
			pst.setString(1, busRegNum);
			pst.setDate(2, date);

			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				flag = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		finally
		{
			con.close();
		}
		return flag;
	}

	public boolean updateBusDetails(UpdateBusTO objupdate) throws ValidationException,
			DatabaseException, SQLException {
		String busRegNum = objupdate.getBusRegNum();
		boolean msg = false;
			String query = "update busdetails set busname= ?, source=?, destination=?,busType=?,startTime=?,endTime=?,fare=?,driverName=?,driverNumber=?,TotalSeats=?,AvailableSeats=?,dateofjourney=? where busRegNum=? ";
			Connection con = SingleTonConnection.getInstance().getConnection();
			PreparedStatement pst;
			try {
				pst = con.prepareStatement(query);
				pst.setString(1, objupdate.getBusname());
				pst.setString(2, objupdate.getSource());
				pst.setString(3, objupdate.getDestination());
				pst.setString(4, objupdate.getBusType());
				pst.setString(5, objupdate.getStartTime());
				pst.setString(6, objupdate.getEndTime());
				pst.setInt(7, objupdate.getFare());
				pst.setString(8, objupdate.getDriverName());
				pst.setString(9, objupdate.getDriverNumber());
				pst.setInt(10, objupdate.getTotalSeats());
				pst.setInt(11, objupdate.getTotalSeats());
				pst.setDate(12, objupdate.getDate());
				pst.setString(13, objupdate.getBusRegNum());
				int n = pst.executeUpdate();
				if (n > 0) {
					msg = true;
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));
			}
			finally
			
			{
				con.close();
			}

		return msg;
	}

	public boolean addBusDetails(AddBusTO admin)
			throws com.cts.exceptions.ValidationException, DatabaseException, SQLException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		AddBusDAO add = new AddBusDAO();

		boolean flag = add.isBusExists(admin.getBusRegNum(), admin.getDate());
		boolean msg = false;
		if (flag == false) {
			Connection con = SingleTonConnection.getInstance().getConnection();
			String busIns = "Insert into Busdetails(busRegNum ,busname,source,destination,busType,startTime,endTime,fare,driverName,driverNumber,TotalSeats,availableseats,dateofjourney) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
			try {
				PreparedStatement pst = con.prepareStatement(busIns);
				pst.setString(1, admin.getBusRegNum());
				pst.setString(2, admin.getBusname());
				pst.setString(3, admin.getSource());
				pst.setString(4, admin.getDestination());
				pst.setString(5, admin.getBusType());
				pst.setString(6, admin.getStartTime());
				pst.setString(7, admin.getEndTime());
				pst.setDouble(8, admin.getFare());
				pst.setString(9, admin.getDriverName());
				pst.setString(10, admin.getDriverNumber());
				pst.setInt(11, admin.getTotalSeats());
				pst.setInt(12, admin.getTotalSeats());
				pst.setDate(13, admin.getDate());
				int n = pst.executeUpdate();
				if (n > 0) {
					msg = true;
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));
			}
			finally{
				con.close();
			}
		}
		return msg;
	}

	public int getfare(String busreg, Date dateofjourney)
			throws ValidationException, DatabaseException, SQLException {
		int fare = 0;
		String query = "select fare from busdetails where busregnum=? and dateofjourney=?";
		Connection con = SingleTonConnection.getInstance().getConnection();
		try {
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, busreg);
			pst.setDate(2, dateofjourney);
			ResultSet rs = pst.executeQuery();
			rs.next();
			fare = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		finally{
			con.close();
		}
		return fare;
	}

	public String cancelTicket(String ticketId) throws ValidationException,
			DatabaseException, SQLException {
		Connection con = SingleTonConnection.getInstance().getConnection();
		String msg = "";
		int p = 0;
		String cmd = "select tickets,busRegNum from ticketdetails where ticketid=?";
		try {
			PreparedStatement pst = con.prepareStatement(cmd);
			pst.setString(1, ticketId);
			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				p = rs.getInt(1);
				String bid = rs.getString(2);
				
				cmd = "update ticketdetails set Status='Cancelled' where TicketId=?";
				pst = con.prepareStatement(cmd);
				pst.setString(1, ticketId);
				pst.executeUpdate();
				cmd = "update busdetails set Availableseats=Availableseats+? where busRegNum=?";
				pst = con.prepareStatement(cmd);
				pst.setInt(1, p);
				pst.setString(2, bid);
				pst.executeUpdate();
				msg = "Ticket Cancelled Successfully...";
			} else {
				msg = "Ticket Not Found";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			msg = e.getMessage();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			
		}
		finally{
			con.close();
		}
		return msg;
	}

}
