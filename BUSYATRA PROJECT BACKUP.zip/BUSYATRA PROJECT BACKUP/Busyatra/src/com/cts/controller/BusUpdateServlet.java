package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.Session;

import org.apache.log4j.Logger;

import com.cts.TO.UpdateBusTO;
import com.cts.helperbo.BusDetailsBo;

/**
 * Servlet implementation class BusUpdateServelet
 */
public class BusUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(BusUpdateServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BusUpdateServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.debug("Inside BusUpdate Servlet : Updating a bus ticket");
		UpdateBusTO admin=new UpdateBusTO();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); 
		java.util.Date dateStr=null;
		try {
			dateStr = formatter.parse(request.getParameter("departuredate"));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		java.sql.Date dateDB = new java.sql.Date(dateStr.getTime());

		admin.setBusRegNum((String)request.getSession().getAttribute("busid"));
		admin.setBusname(request.getParameter("busname"));
		admin.setSource(request.getParameter("source"));
		admin.setDestination(request.getParameter("destination"));
		admin.setBusType(request.getParameter("busType"));
		admin.setStartTime(request.getParameter("departure"));
		admin.setEndTime(request.getParameter("arrival"));
		admin.setFare(Integer.parseInt(request.getParameter("seatPrice")));
		admin.setDriverName(request.getParameter("driverName"));
		admin.setDriverNumber(request.getParameter("driverNumber"));
		admin.setTotalSeats(Integer.parseInt(request.getParameter("totalSeats")));
		admin.setAvailableSeats(Integer.parseInt(request.getParameter("availableSeats")));
		admin.setDate(dateDB);

		try {
			BusDetailsBo.updateBusDetails(admin);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.sendRedirect("UpdateSucess.html");



	}
}


