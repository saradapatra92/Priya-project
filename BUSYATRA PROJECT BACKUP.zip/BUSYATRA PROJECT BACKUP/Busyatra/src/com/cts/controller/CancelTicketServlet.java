package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;





import org.apache.log4j.Logger;

import com.cts.helperbo.BusDetailsBo;
import com.cts.TO.CancelTO;

/**
 * Servlet implementation class CancelTicketServlet
 */
public class CancelTicketServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(CancelTicketServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	public CancelTicketServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.debug("Inside CancelTicket Servlet : Cancelling a bus ticket");
		PrintWriter out = response.getWriter();
		String ticketId=(String)request.getParameter("ticketId");
		try {
			BusDetailsBo.cancelTicket(ticketId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		RequestDispatcher rd=request.getRequestDispatcher("Cancel.jsp");
		rd.include(request, response); 

		out.println("<script>document.getElementById('result2').style.visibility = 'visible';</script>");
	}


}

