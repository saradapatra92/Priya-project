package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




import org.apache.log4j.Logger;

import com.cts.helperbo.BusDetailsBo;
import com.cts.TO.DeleteBusTO;

/**
 * Servlet implementation class DeleteBusServelet
 */
public class DeleteBusServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(DeleteBusServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DeleteBusServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		logger.debug("Inside DeleteBusServelet Servlet : Deleting Bus Details ");
		DeleteBusTO objDelete= new DeleteBusTO();
		objDelete.setBusRegNum(request.getParameter("busregNo"));
		boolean res;
		try {
			res = BusDetailsBo.deleteBusDetails(objDelete);
			PrintWriter out=response.getWriter();
			if(res==true){

				response.sendRedirect("welcomeadmin.html");
			}
			else

				response.sendRedirect("BusDelete.jsp");
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
