package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cts.TO.UserDetails;
import com.cts.helperbo.LoginDetailsBo;

/**
 * Servlet implementation class UserDetailsServlet
 */
public class UserDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(UserDetailsServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserDetailsServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.debug("Inside UserDetailsServlet Servlet : Getting UserDetails ");
		UserDetails objUser= new UserDetails();
		objUser.setName(request.getParameter("name"));
		objUser.setEmail(request.getParameter("email"));
		objUser.setPassword(request.getParameter("password"));
		objUser.setMobileNo(request.getParameter("mobile"));
		objUser.setGender(request.getParameter("gender"));
		objUser.setAddress(request.getParameter("address"));
		objUser.setCity(request.getParameter("city"));
		objUser.setState(request.getParameter("state"));
		objUser.setCountry(request.getParameter("country"));


		boolean res;
		try {
			res = LoginDetailsBo.addUserDetails(objUser);
			if(res){
				response.sendRedirect("Login.jsp");
			}
			else{
				request.setAttribute("msg", "User already exist");
				request.getRequestDispatcher("SignUp.jsp").forward(request, response);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
