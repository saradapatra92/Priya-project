package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.helperbo.BusDetailsBo;

/**
 * Servlet implementation class UpdateBusDetailsServlet
 */
public class UpdateBusDetailsServlet extends HttpServlet {

	private static Logger logger = Logger.getLogger(UpdateBusDetailsServlet.class);
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateBusDetailsServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.debug("Inside UpdateBusDetailsServlet Servlet : Updating BusDetails ");
		String busRegno=request.getParameter("name");
		boolean res;
		try {
			res = BusDetailsBo.isBusExists(busRegno);
			if(res==true){
				HttpSession session= request.getSession(true);
				session.setAttribute("busid", request.getParameter("name"));
				RequestDispatcher disp=request.getRequestDispatcher("UpdateBus.jsp");
				disp.forward(request, response);
			}
			else {
				RequestDispatcher disp=request.getRequestDispatcher("UpdateError.html");
				disp.forward(request, response);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}


