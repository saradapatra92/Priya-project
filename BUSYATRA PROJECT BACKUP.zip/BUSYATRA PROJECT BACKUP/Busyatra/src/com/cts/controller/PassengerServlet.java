package com.cts.controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.TO.PassengerTO;
import com.cts.TO.TicketTO;
import com.cts.helperbo.BusDetailsBo;

/**
 * Servlet implementation class PassengerServlet
 */
public class PassengerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(PassengerServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PassengerServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.debug("Inside PassengerServlet Servlet : Show Passenger Details ");
		HttpSession session=request.getSession(true);
		String name= request.getParameter("name");
		String age= (request.getParameter("age"));
		String mobile= request.getParameter("contactnumber");
		String email= request.getParameter("email");
		String gender= request.getParameter("gender");	

		String bus=(String)session.getAttribute("busid");
		if(bus==null){
			bus=(String)session.getAttribute("busId");
		}
		
		int seats=Integer.parseInt(session.getAttribute("seats").toString());
		String jdate=(String)session.getAttribute("jdate");
		SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
		String custid=(String)session.getAttribute("custid");  


		Date journeyDate=null;
		try {
			journeyDate = (Date)new Date(sdf.parse(jdate).getTime());
		} catch (ParseException e1) {
			e1.printStackTrace();
			logger.error("Error %%%%" + e1);
		}
		BusDetailsBo bo= new BusDetailsBo();

		PassengerTO objPassenger= new PassengerTO();
		objPassenger.setName(name);
		objPassenger.setAge(age);
		objPassenger.setNumber(mobile);
		objPassenger.setEmail(email);
		objPassenger.setGender(gender);
		objPassenger.setBusid(bus);
		objPassenger.setSeats(seats);
		objPassenger.setJourneyDate(journeyDate);
		objPassenger.setCustid(custid);
		try {
			objPassenger.setFare(bo.getFare(bus, jdate));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		session = request.getSession();
		session.setAttribute("objPassenger", objPassenger);

		request.getRequestDispatcher("Payment.jsp").forward(request, response);

	}
}


