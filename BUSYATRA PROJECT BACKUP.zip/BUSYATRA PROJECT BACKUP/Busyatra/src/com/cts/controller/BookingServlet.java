package com.cts.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cts.TO.BookingTO;
import com.cts.TO.BusTO;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;
import com.cts.helperbo.BusDetailsBo;

/**
 * Servlet implementation class BookingServelet
 */
public class BookingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(BookingServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BookingServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.debug("Inside Bookinf Servlet : Booking a bus ticket");
		BookingTO objBooking= new BookingTO();
		SimpleDateFormat sdf= new SimpleDateFormat("MM/dd/yyyy");
		Date date=null;
		try {
			date = sdf.parse(request.getParameter("date"));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		objBooking.setSource(request.getParameter("source"));
		objBooking.setDestination(request.getParameter("destination"));
		objBooking.setStartDate(date);

		try {
			try {
				List<BusTO> arrayBus= BusDetailsBo.getBusDetails(objBooking);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error %%%%" + e);
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error %%%%" + e);
		}


	}

}
