package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;

import org.apache.log4j.Logger;

import com.cts.TO.UserLogin;
import com.cts.exceptions.BusinessExceptions;
import com.cts.helperbo.LoginDetailsBo;

/**
 * Servlet implementation class UserLoginServlet
 */
public class UserLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(UserLoginServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserLoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		logger.debug("Inside UserLoginServlet Servlet : Perform Authentication ");
		UserLogin objLogin= new UserLogin();
		String user=request.getParameter("loginid");
		String pwd=request.getParameter("pass");
		objLogin.setUserId(request.getParameter("loginid"));
		objLogin.setPassword(request.getParameter("pass"));
		HttpSession s=request.getSession(true);

		String res;
		try {
			res = LoginDetailsBo.validateLoginDetails(user,pwd);
			if(res!=null)
			{
				if(request.getParameter("loginid").equals("ADMIN"))
				{
					response.sendRedirect("welcomeadmin.html");
				}
				else
				{
					HttpSession session = request.getSession(true);
					String busid=(String)session.getAttribute("busid");
					String sea=(String)session.getAttribute("seats");
					String da=(String)session.getAttribute("jdate");

					session.setAttribute("custid", request.getParameter("loginid"));
					session.setAttribute("custName",res);
					if(busid!=null)
					{
						response.sendRedirect("PassengerDetails.jsp");

					}
					else
					{
						response.sendRedirect("BusBooking.jsp");

					}

				}

			}
			else
			{
				HttpSession session = request.getSession(true);
			//	session.setAttribute("message", message);
				PrintWriter out= response.getWriter();
				RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
				rd.include(request, response);
				out.println("<script>document.getElementById('result').style.visibility = 'visible';</script>");
			
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	//	PrintWriter out= response.getWriter();
		

	}

}
