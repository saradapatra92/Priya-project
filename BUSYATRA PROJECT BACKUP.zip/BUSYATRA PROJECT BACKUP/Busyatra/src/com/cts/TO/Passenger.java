package com.cts.TO;

import java.sql.Date;

public class Passenger {

	private String customerName;
	private String busRegNum;
	private String age;
	private String gender;
	private Date dateofjourney;
	private String ticketStatus;
	private String custid;

	public String getCustid() {
		return custid;
	}
	public void setCustid(String custid) {
		this.custid = custid;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getBusRegNum() {
		return busRegNum;
	}
	public void setBusRegNum(String busRegNum) {
		this.busRegNum = busRegNum;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getDateofjourney() {
		return dateofjourney;
	}
	public void setDateofjourney(Date dateofjourney) {
		this.dateofjourney = dateofjourney;
	}
	public String getTicketStatus() {
		return ticketStatus;
	}
	public void setTicketStatus(String ticketStatus) {
		this.ticketStatus = ticketStatus;
	}



}
