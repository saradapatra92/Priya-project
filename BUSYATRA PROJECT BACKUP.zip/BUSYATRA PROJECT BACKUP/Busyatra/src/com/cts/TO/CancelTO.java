package com.cts.TO;

public class CancelTO {

	public String ticketId;
	public String email;

	public String getTicketId() {
		return ticketId;
	}
	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}


	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public CancelTO(String ticketId, String email) 
	{
		this.ticketId = ticketId;
		this.email= email;
	}
	public CancelTO() 
	{

	}
}
