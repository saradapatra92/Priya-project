package com.cts.TO;

import java.util.Date;

public class BusTO {

	private String busReg;
	private String type;
	private String stime;
	private String etime;
	private int seats;
	private int fare;
	private java.sql.Date journeyDate;
	
	public java.sql.Date getJourneyDate() {
		return journeyDate;
	}
	public void setJourneyDate(java.sql.Date journeyDate) {
		this.journeyDate = journeyDate;
	}
	public String getBusReg() {
		return busReg;
	}
	public void setBusReg(String busReg) {
		this.busReg = busReg;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getStime() {
		return stime;
	}
	public void setStime(String stime) {
		this.stime = stime;
	}
	public String getEtime() {
		return etime;
	}
	public void setEtime(String etime) {
		this.etime = etime;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	public BusTO(String busReg, String type, String stime, String etime, int seats,
			int fare) {
		this.busReg = busReg;
		this.type = type;
		this.stime = stime;
		this.etime = etime;
		this.seats = seats;
		this.fare = fare;
	}
	public BusTO() {
	}
	
	
	
}
