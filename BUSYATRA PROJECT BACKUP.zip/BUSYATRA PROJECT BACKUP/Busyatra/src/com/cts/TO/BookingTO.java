package com.cts.TO;

import java.sql.Date;

public class BookingTO {

	private String source;
	private String destination;
	private java.sql.Date startDate;
	private int seats;

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public java.sql.Date getStartDate() {
		return startDate;
	}

	public void setStartDate(java.util.Date date) {
		this.startDate = (Date) date;
	}

	public int getSeats() {
		return seats;
	}

	public void setSeats(int seats) {
		this.seats = seats;
	}

	public BookingTO(String source, String destination,
			java.sql.Date startDate, int seats) {
		this.source = source;
		this.destination = destination;
		this.startDate = startDate;
		this.seats = seats;
	}

	public BookingTO() {
	}

	@Override
	public String toString() {
		return "BookingTO [source=" + source + ", destination=" + destination
				+ ", startDate=" + startDate + ", seats=" + seats + "]";
	}

}
