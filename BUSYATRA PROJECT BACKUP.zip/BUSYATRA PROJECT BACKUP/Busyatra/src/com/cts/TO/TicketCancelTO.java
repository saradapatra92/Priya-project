package com.cts.TO;

import java.sql.Date;

public class TicketCancelTO {

	public String busRegNum; 
	public String status;
	public String custid; 
	public String ticketid; 
	public String busname;
	public String source;
	public String destination;
	public java.sql.Date bookingdate;
	public java.sql.Date journeydate;
	public String arrivaltime;
	public String departtime;

	public String getBusRegNum() {
		return busRegNum;
	}
	public void setBusRegNum(String busRegNum) {
		this.busRegNum = busRegNum;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCustid() {
		return custid;
	}
	public void setCustid(String custid) {
		this.custid = custid;
	}
	public String getTicketid() {
		return ticketid;
	}
	public void setTicketid(String ticketid) {
		this.ticketid = ticketid;
	}
	public String getBusname() {
		return busname;
	}
	public void setBusname(String busname) {
		this.busname = busname;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public java.sql.Date getBookingdate() {
		return bookingdate;
	}
	public void setBookingdate(java.sql.Date bookingdate) {
		this.bookingdate = bookingdate;
	}
	public java.sql.Date getJourneydate() {
		return journeydate;
	}
	public void setJourneydate(java.sql.Date journeydate) {
		this.journeydate = journeydate;
	}
	public String getArrivaltime() {
		return arrivaltime;
	}
	public void setArrivaltime(String arrivaltime) {
		this.arrivaltime = arrivaltime;
	}
	public String getDeparttime() {
		return departtime;
	}
	public void setDeparttime(String departtime) {
		this.departtime = departtime;
	}
	public TicketCancelTO(String busRegNum, String status, String custid,
			String ticketid, String busname, String source, String destination,
			Date bookingdate, Date journeydate, String arrivaltime,
			String departtime) {
		super();
		this.busRegNum = busRegNum;
		this.status = status;
		this.custid = custid;
		this.ticketid = ticketid;
		this.busname = busname;
		this.source = source;
		this.destination = destination;
		this.bookingdate = bookingdate;
		this.journeydate = journeydate;
		this.arrivaltime = arrivaltime;
		this.departtime = departtime;
	}
	public TicketCancelTO() {
		// TODO Auto-generated constructor stub
	}
}
