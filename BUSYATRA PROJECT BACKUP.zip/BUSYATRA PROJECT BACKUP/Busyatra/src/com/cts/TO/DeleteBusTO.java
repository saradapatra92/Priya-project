package com.cts.TO;

public class DeleteBusTO {

	public String busRegNum;

	public String getBusRegNum() {
		return busRegNum;
	}

	public void setBusRegNum(String busRegNum) {
		this.busRegNum = busRegNum;
	}
	public DeleteBusTO() {
		// TODO Auto-generated constructor stub
	}

	public DeleteBusTO(String busRegNum) {
		super();
		this.busRegNum = busRegNum;
	}

}
