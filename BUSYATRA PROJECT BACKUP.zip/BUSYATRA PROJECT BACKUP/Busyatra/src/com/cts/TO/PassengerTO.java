package com.cts.TO;

import java.sql.Date;

public class PassengerTO {

	private Date journeyDate;
	private String name;
	private String age;
	private String number;
	private String email;
	private String gender;
	private String busid;
	private int seats;
	private int fare;
	private String custid;

	public String getCustid() {
		return custid;
	}
	public void setCustid(String custid) {
		this.custid = custid;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	public Date getJourneyDate() {
		return journeyDate;
	}
	public void setJourneyDate(Date journeyDate) {
		this.journeyDate = journeyDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBusid() {
		return busid;
	}
	public void setBusid(String busid) {
		this.busid = busid;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}

	public PassengerTO(Date journeyDate, String name, String age, String number,
			String email, String gender, String busid, int seats) {
		this.journeyDate = journeyDate;
		this.name = name;
		this.age = age;
		this.number = number;
		this.email = email;
		this.gender = gender;
		this.busid = busid;
		this.seats = seats;
	}

	public PassengerTO() {
	}



}
