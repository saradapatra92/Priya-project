package com.cts.TO;

import java.util.Date;

public class AddBusTO 
{
	public String busRegNum;
	public String busname;
	public String source;
	public String destination;
	public String busType;
	public String startTime;
	public String endTime;
	public int fare;
	public String  driverName ;
	public String driverNumber ;
	public int totalSeats ;
	public java.sql.Date departureDate;

	public String getBusRegNum() {
		return busRegNum;
	}
	public void setBusRegNum(String busRegNum) {
		this.busRegNum = busRegNum;
	}
	public String getBusname() {
		return busname;
	}
	public void setBusname(String busname) {
		this.busname = busname;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	public String getDriverName() {
		return driverName;
	}
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	public String getDriverNumber() {
		return driverNumber;
	}
	public void setDriverNumber(String driverNumber) {
		this.driverNumber = driverNumber;
	}
	public int getTotalSeats() {
		return totalSeats;
	}
	public void setTotalSeats(int totalSeats) {
		this.totalSeats = totalSeats;
	}

	public java.sql.Date getDate() {
		return departureDate;
	}
	public void setDate(java.sql.Date departureDate) {
		this.departureDate = (java.sql.Date) departureDate;
	}
	public AddBusTO() 
	{
		super();
	}
	public AddBusTO( String busRegNum, String busname,
			String source, String destination, String busType,
			String startTime, String endTime, int fare,
			String driverName, String driverNumber, int totalSeats,
			java.sql.Date departureDate) {
		super();
		this.busRegNum = busRegNum;
		this.busname = busname;
		this.source = source;
		this.destination = destination;
		this.busType = busType;
		this.startTime = startTime;
		this.endTime = endTime;
		this.fare = fare;
		this.driverName = driverName;
		this.driverNumber = driverNumber;
		this.totalSeats = totalSeats;
		this.departureDate = departureDate;
	}




}
