package com.cts.TO;

public class UserLogin {


	private String userId;
	private String password;
	public static String custId=null;


	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		custId=userId;
		
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public UserLogin(String userId, String password) {
		this.userId = userId;
		this.password = password;
	}

	public UserLogin() {
	}




}
