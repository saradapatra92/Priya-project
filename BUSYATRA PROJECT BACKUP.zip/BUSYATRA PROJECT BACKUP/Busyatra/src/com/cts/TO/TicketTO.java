package com.cts.TO;

import java.sql.Date;

public class TicketTO {

	private String customerId;
	private String TicketId;
	private String busName;
	private String source;
	private String destination;
	private String dtime;
	private String atime;
	private Date journeyDate;
	private Date bookingDate;
	private String name;
	private String age;
	private String number;
	private String email;
	private String gender;
	private String busid;
	private int seats;
	private int fare;
	private String dname;
	private String dnumber;




	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getDnumber() {
		return dnumber;
	}
	public void setDnumber(String dnumber) {
		this.dnumber = dnumber;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getTicketId() {
		return TicketId;
	}
	public void setTicketId(String ticketId) {
		TicketId = ticketId;
	}
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getDtime() {
		return dtime;
	}
	public void setDtime(String dtime) {
		this.dtime = dtime;
	}
	public String getAtime() {
		return atime;
	}
	public void setAtime(String atime) {
		this.atime = atime;
	}
	public Date getJourneyDate() {
		return journeyDate;
	}
	public void setJourneyDate(Date journeyDate) {
		this.journeyDate = journeyDate;
	}
	public Date getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBusid() {
		return busid;
	}
	public void setBusid(String busid) {
		this.busid = busid;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}



	public TicketTO(String customerId, String ticketId, String busName,
			String source, String destination, String dtime, String atime,
			Date journeyDate, Date bookingDate, String name, String age,
			String number, String email, String gender, String busid,
			int seats, int fare, String dname, String dnumber) {
		this.customerId = customerId;
		TicketId = ticketId;
		this.busName = busName;
		this.source = source;
		this.destination = destination;
		this.dtime = dtime;
		this.atime = atime;
		this.journeyDate = journeyDate;
		this.bookingDate = bookingDate;
		this.name = name;
		this.age = age;
		this.number = number;
		this.email = email;
		this.gender = gender;
		this.busid = busid;
		this.seats = seats;
		this.fare = fare;
		this.dname = dname;
		this.dnumber = dnumber;
	}
	public TicketTO() {
	}

}