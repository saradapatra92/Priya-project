package com.cts.helperbo;

import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.cts.TO.TicketCancelTO;
import com.cts.dao.TicketDetailsDao;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;

public class TicketDetailsBo {


	private static Logger logger = Logger.getLogger(TicketDetailsBo.class);
	
	public static List<TicketCancelTO> showTickets(String user) throws ValidationException, DatabaseException, SQLException{
		logger.info("Calling validateLogin method...");
		TicketDetailsDao objTicketDao=new TicketDetailsDao(); 
		logger.info("validateLogin method executed Successfully...");
		return objTicketDao.showTickets(user);
	}
}
