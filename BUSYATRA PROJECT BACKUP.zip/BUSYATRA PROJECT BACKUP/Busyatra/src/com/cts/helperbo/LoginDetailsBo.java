package com.cts.helperbo;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cts.TO.UserDetails;
import com.cts.TO.UserLogin;
import com.cts.dao.LoginDetailsDao;

public class LoginDetailsBo {

	private static Logger logger = Logger.getLogger(LoginDetailsBo.class);
	
	public static String validateLoginDetails(String email,String pwd) throws SQLException{
		logger.info("Calling validateLogin method...");
		LoginDetailsDao loginDao=new LoginDetailsDao();
		logger.info("ValidateLogin method executed Successfully...");
		return loginDao.validateLoginDetails(email,pwd);
	}
	
	public static boolean isUserExists(String email) throws SQLException{
		logger.info("Calling userExists method...");
		LoginDetailsDao loginDao=new LoginDetailsDao();
		logger.info("userExists method executed Successfully...");
		return loginDao.isUserExists(email);
	}
	
	public static boolean addUserDetails(UserDetails objUser) throws SQLException
	{
		logger.info("Calling createUser method...");
		LoginDetailsDao loginDao=new LoginDetailsDao(); 
		logger.info("createUser method executed Successfully...");
		return loginDao.addUserDetails(objUser);
	}
	
	
}
