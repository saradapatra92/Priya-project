package com.cts.helperbo;

import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.log4j.Logger;

import com.cts.TO.AddBusTO;
import com.cts.TO.BookingTO;
import com.cts.TO.BusTO;
import com.cts.TO.CancelTO;
import com.cts.TO.DeleteBusTO;
import com.cts.TO.Passenger;
import com.cts.TO.PassengerTO;
import com.cts.TO.TicketTO;
import com.cts.TO.UpdateBusTO;
import com.cts.controller.BookingServlet;
import com.cts.dao.AddBusDAO;
import com.cts.dao.BusDetailsDao;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;

public class BusDetailsBo {

	private static Logger logger = Logger.getLogger(BusDetailsBo.class);
	
	public static String addPassengerDetails(Passenger p) throws SQLException{
		logger.info("Calling addPassengerDetails method...");
		AddBusDAO objBusdetails=new AddBusDAO(); 
		String res="";
		try {
			res=objBusdetails.addPassengerDetails(p);
			logger.info("addPassengerDetails method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}
	
	public static void updateBusDetails(UpdateBusTO objupdate) throws SQLException
	{
		logger.info("Calling updateBusDetails method...");
		BusDetailsDao objBusdetails=new BusDetailsDao();
		boolean res=false;
		try {
			res=objBusdetails.updateBusDetails(objupdate);
			logger.info("updateBusDetails method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		//return res;
	}
	
	public static TicketTO bookTicket(PassengerTO objPassenger){
		
		logger.info("Calling bookTicket method...");
		BusDetailsDao objBusdetails=new BusDetailsDao();
		TicketTO obj=null;
		try {
			obj=objBusdetails.bookTicket(objPassenger);
			logger.info("BookTicket method executed Successfully...");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return obj;
	}
	
	
	public static boolean isBusExists(String busRegNum) throws SQLException{
		
		logger.info("Calling isBusExists method...");
		BusDetailsDao objBusdetails=new BusDetailsDao();
		boolean res=false;
		try {
			res=objBusdetails.isBusExists(busRegNum);
			logger.info("isBusExists method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}
	
	public static boolean deleteBusDetails(DeleteBusTO objDelete) throws SQLException
	{
		logger.info("Calling deleteBusDetails method...");
		BusDetailsDao objBusdetails=new BusDetailsDao();
		boolean res=false;
		try {
			res=objBusdetails.deleteBusDetails(objDelete);
			logger.info("deleteBusDetails method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}
	
	
	
	public static String cancelTicket(String ticketId) throws SQLException 
	{
		logger.info("Calling cancelTicket method...");
		BusDetailsDao objBusdetails=new BusDetailsDao();
		String res="";
		try {
			res=objBusdetails.cancelTicket(ticketId);
			logger.info("cancelTicket method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}
	
	public static List<BusTO> getBusDetails(BookingTO objBooking) throws DatabaseException, ValidationException, SQLException{
		logger.info("Calling getBusDetails method...");
		BusDetailsDao objBusdetails=new BusDetailsDao();
		logger.info("getBusDetails method executed Successfully...");
		return objBusdetails.getBusDetails(objBooking);
	}
	
	public static boolean isBusExists(String busRegNum, Date date) throws SQLException 
	{
		logger.info("Calling isBusExists method...");
		BusDetailsDao objBusdetails=new BusDetailsDao();
		boolean res=false;
		try {
			res=objBusdetails.isBusExists(busRegNum, date);
			logger.info("isBusExists method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}
	
	public static boolean addBusDetails(AddBusTO admin) throws SQLException{
		logger.info("Calling addBusDetails method...");
		BusDetailsDao objBusdetails=new BusDetailsDao();
		boolean res=false;
		try {
			res= objBusdetails.addBusDetails(admin);
			logger.info("addBusDetails method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}
	
	public static int getFare(String busreg,String dateofjourney) throws SQLException{
		logger.info("Calling getFare method...");
		BusDetailsDao objBusdetails=new BusDetailsDao();
		int fare=0;
		try {
			SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
			 Date journeyDate = (Date)new Date(sdf.parse(dateofjourney).getTime());
		        
			fare=objBusdetails.getfare(busreg,journeyDate);
			logger.info("getFare method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return fare;
		
	}
	
	
}
