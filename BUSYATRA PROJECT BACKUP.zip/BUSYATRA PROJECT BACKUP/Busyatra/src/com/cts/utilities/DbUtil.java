package com.cts.utilities;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import com.cts.constants.DatabaseConstants;



public class DbUtil {
	private static Connection connection = null;
	private static Properties prop = new Properties();

	DbUtil() {
	}

	public static Connection getConnection() {
		try {

			//prop.load(new FileInputStream("resources/db.properties"));
			prop.load(new FileInputStream(DatabaseConstants.DBPROPERTIES));

			String driver = prop.getProperty(DatabaseConstants.DATABASEDRIVER);
			String url = prop.getProperty(DatabaseConstants.DATABASEURL);
			String user = prop.getProperty(DatabaseConstants.DATABASEUSERNAME);
			String password = prop.getProperty(DatabaseConstants.DATABASEPASSWORD);

			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
	
			//System.out.println(driver+":"+url);
		} catch (Exception ex) {
			System.out.println("error " + ex.getMessage());
		}
		return connection;
	}

	public static void main(String[] args) {
		getConnection();
	}
}
