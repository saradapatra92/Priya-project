package com.cts.utilities;

import java.util.Locale;
import java.util.ResourceBundle;

public class PropertyUtil {
	public static String getMessage(String key)
	{
		Locale locale=Locale.getDefault();
		ResourceBundle resourceBundle = ResourceBundle.getBundle("messages",locale);
		String str ="ee";
		return resourceBundle.getString(key);
	}
}
