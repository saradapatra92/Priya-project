package com.cts.datasource;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class SingleTonConnection {
	
	 private static SingleTonConnection dataSource;
	   private static ComboPooledDataSource comboPooledDataSource;

	   private SingleTonConnection() {
		   ResourceBundle rb=ResourceBundle.getBundle("db");
			
			String driver=rb.getString("driver");
			String url=rb.getString("url");
			String username=rb.getString("username");
			String password=rb.getString("password");
	      try {
	         comboPooledDataSource = new ComboPooledDataSource();
	         comboPooledDataSource
	            .setDriverClass(driver);
	         comboPooledDataSource
	            .setJdbcUrl(url);
	         comboPooledDataSource.setUser(username);
	         comboPooledDataSource.setPassword(password);
	      }
	      catch (PropertyVetoException ex1) {
	         ex1.printStackTrace();
	      }
	   }

	   public static SingleTonConnection getInstance() {
	      if (dataSource == null)
	         dataSource = new SingleTonConnection();
	      return dataSource;
	   }

	   public Connection getConnection() {
	      Connection con = null;
	      try {
	         con = comboPooledDataSource.getConnection();
	      } catch (SQLException e) {
	         e.printStackTrace();
	      }
	      return con;
	   }
	
	
	
}
