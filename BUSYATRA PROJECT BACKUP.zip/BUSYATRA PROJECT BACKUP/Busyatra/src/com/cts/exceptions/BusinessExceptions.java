package com.cts.exceptions;

public class BusinessExceptions extends Exception {
	String message = null;

	public BusinessExceptions(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
}
