package com.cts.exceptions;

public class DatabaseException extends Exception {

	String message = null;

	public DatabaseException(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
}
